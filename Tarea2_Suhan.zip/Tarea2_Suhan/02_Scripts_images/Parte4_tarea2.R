###Script ejercicios####
########################

#Parte 4.

#Cargamos las paqueterías necesarias 
library(igraph)
library(igraphdata)
data("yeast")

#Con la siguiente función vamos a calcular la distribución de conectividades y posteriormente la graficamos esa distribución 
degree_distribution(yeast)->Distrib_conex
Distrib_conex
hist(Distrib_conex, main = "Distribución de conexiones en la levadura", xlab = "Distribución de degree", ylab = "Frecuencia")

##Con lo siguiente tenemos el boxplot
boxplot(Distrib_conex, main= "Boxplot Distribución degree") 

#Degree
degree(yeast)->Conex
Conex
class(Conex)

#Podemos solicitar con la siguiente función, que se cuenten el número de redes con 15 o más conexiones

Num<-0
for (i in Conex) {
  if (i >= 15) {
    Num<-Num+1
  } 
  
  i<-i+1
}

Num

Num2<-0
for (i in Conex) {
  if (i < 15) {
    Num2<-Num2+1
  } 
  
  i<-i+1
}

Num2

yeast

##Para calcular el degre maximo de la red.
max(Conex)
which(Conex==118)
min(Conex)

##Para calcular el diametro
diameter(yeast)

##Vamos a buscar los 10 nodos con mayor conexiones y los vamos a ir eliminando, para despuñes calcular el diametro de la red
##Con etso se muestran los nodos con sus mayores conexionesy los guardo en un vector

ConexAsc<-sort(Conex, decreasing = TRUE)
ConexAsc
Big<-ConexAsc[1:10] ##Seleccionamos los 10 primeros y los guardamos
Big

#Aquí ya tenemos los 10 nodos más conectados y los vamos a eliminar y calcular el diamétro
#Como no conocemos la posición en la red, buscamos sus nombres con lo siguiente:
names(Big)

##Con cualquiera de esta podemos buscar, la posición de esa conexión para eliminarla en la red
which(Conex == Conex["YPR110C"])

#Y vamos a eliminar ese nodo
yeastie<-delete_vertices(yeast, 286)
diameter(yeastie)

##Y continuamos con los demás. 
#Pero ojo, la posición del nodo puede cambiar, por eso es necesario calcular el degree y verificar el nodo a ekiminar
Conex2<-degree(yeastie)
which(Conex2 == Conex2["YPL131W"])
yeastie2<-delete_vertices(yeastie, 697)
diameter(yeastie2)

Conex3<-degree(yeastie2)
which(Conex3 == Conex3["YNL178W"])
yeastie3<-delete_vertices(yeastie2, 711)
diameter(yeastie3)

Conex4<-degree(yeastie3)
which(Conex4 == Conex4["YIL021W"])
yeastie4<-delete_vertices(yeastie3, 70)
diameter(yeastie4)

Conex5<-degree(yeastie4)
which(Conex5 == Conex5["YOL127W"])
yeastie5<-delete_vertices(yeastie4, 122)
diameter(yeastie5)

Conex6<-degree(yeastie5)
which(Conex6 == Conex6["YJL063C"])
yeastie6<-delete_vertices(yeastie5, 137)
diameter(yeastie6)

Conex7<-degree(yeastie6)
which(Conex7 == Conex7["YBR283C"])
yeastie7<-delete_vertices(yeastie6, 716)
diameter(yeastie7)

Conex8<-degree(yeastie7)
which(Conex8 == Conex8["YLR378C"])
yeastie8<-delete_vertices(yeastie7, 716)
diameter(yeastie8)

Conex9<-degree(yeastie8)
which(Conex9 == Conex9["YMR260C"])
yeastie9<-delete_vertices(yeastie8, 834)
diameter(yeastie9)

Conex10<-degree(yeastie9)
which(Conex10 == Conex10["YBR251W"])
yeastie10<-delete_vertices(yeastie9, 65)
diameter(yeastie10)

##Medidas de centralidad

#El mismo degree nos puede hablar de la importancia de cada nodo. Ya concemos al menos los 10 más grandes
Big

#Veamos
CG<-centralization.degree(yeast) #Este se parece mucho al degree, habla de las conexiones que tiene.

#El numero de pasos para acceder a ese nodo,y elegimos los 10 más cortos, ya que seguro su mañximo es más centrico
closeness(yeast)->Clo
CloS<-sort(Clo)
CloS[1:10]

#####Clusterización
#Usamos el siguiente código por el primer método:

EByeast<-cluster_edge_betweenness(yeast,directed = FALSE)
membership(EByeast) ##Aquí aparece el vector de quién pertenece a cada grupo
table(membership(EB)) ##Aquí cuantos pertenece a cada grupo





