###Script ejercicios####
########################

#Parte 3.

##Primero cargamos la matriz de adyacencia:
red_ma<-read.csv2("01_Raw_Data/Matriz_Tarea2.csv")
red_ma

#Revisamos la red, porque debemos verificar información de la tabla y después convertirlo en una matriz
View(red_ma)

#Cambiar los nombres de los renglones, ya que están númericos. Tomamos la columna 1, y se los ponemos a los renglos con lo siguiente:
row.names(red_ma)<-red_ma[,1]

#Después quitamos la columna
red_ma<-red_ma[,-1]

#Y transformamos los datos a matriz
red_ma<-as.matrix(red_ma)
class(red_ma)

##1. Primero definimos si es una red dirigida o no dirigida, considerando el Degree de cada nodo####
#El degree se calcula sumando los valores en el renglón (para la matriz de adyacencia, estos serían los "in" o de entrada).

degree<-c()
r<-1

for (i in 1:10) {
    degree<-c(degree, sum(red_ma[r,]))
    r<-r+1
  }

degree

#Con esto podemos ver el degree de cada nodo, con su nombre
names(degree)<-LETTERS[1:10]
degree

##Ahora si deseamos comparar con los "outputs" o de salida tendríamos que usar la siguiente función
degreeOut<-c()
c<-1

for (j in 1:10) {
  degreeOut<-c(degreeOut, sum(red_ma[,c]))
  c<-c+1
}

degreeOut

##Colocamos nombres
names(degreeOut)<-LETTERS[1:10]
degreeOut

#Podemos comparar los valores de entrada y salida, y si es distinto, entonces es una red dirigida, de lo contrario no dirigida

if (all(degree) == all(degreeOut)) {
  print("Tu red es no dirigida")
} else {print("Tu red es dirigida")
    }

##3. Degree####
#Sumamos los degree
Degreeall<-c()
x<-1

for (i in 1:10) {
  Degreeall<-c(Degreeall,sum(degree[x] + degreeOut[x]))
  x<-x+1
}

Degreeall
names(Degreeall)<-LETTERS[1:10]
Degreeall

##4, histograma del degree####
hist(Degreeall, main = "Valores de degree en la red", xlab = "Valor del Degree", ylab = "Frecuencia", col = "steelblue1")

